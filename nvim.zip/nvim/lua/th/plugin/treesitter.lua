return {
    'nvim-treesitter/nvim-treesitter',
    build = ':TSUpdate',
}

