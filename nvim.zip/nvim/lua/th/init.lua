require('lazy').setup('th.plugin')
require('th.remap')
require('th.set')
